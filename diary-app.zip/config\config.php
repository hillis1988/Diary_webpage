<?php

declare(strict_types=1);

/**
 * Real configuration for the mental health diary.
 *
 * This file is NEVER committed to git and NEVER uploaded into the public/
 * folder. It only lives in config/ on the server, outside the document root.
 */

return [
    'app' => [
        'env' => 'production',

        'base_url' => 'https://www.royhillis.co.uk',

        'force_https' => true,

        // IONOS terminates TLS in front of the app, so this header can be trusted.
        'trust_forwarded_proto' => true,
    ],

    'database' => [
        'host' => 'db5021064278.hosting-data.io',
        'port' => 3306,
        'name' => 'dbs15962756',
        'user' => 'dbu2596331',
        'password' => 'Bodybuilder1988!!',

        'charset' => 'utf8mb4',
    ],

    'encryption' => [
        // 32 random bytes, base64 encoded. Generated for this deployment only.
        'master_key_base64' => 'dUHQrWPF6HWpHnznGyrTuZ32bXVFXp/ppEswAZYB2Uw=',
    ],

    'ai' => [
        'enabled' => true,

        'provider' => 'openai',

        'endpoint' => 'https://api.openai.com/v1/chat/completions',

        'api_key' => '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',

        'model' => 'gpt-4o-mini',

        'timeout_seconds' => 20,

        'retries' => 1,
    ],

    'cron' => [
        // Random shared secret, generated for this deployment only.
        'token' => 'd28298090f777a6e8e8a68bc09236a6c8a314b904e63d7ca84b5c3cc3a14ec6e',
    ],
];
